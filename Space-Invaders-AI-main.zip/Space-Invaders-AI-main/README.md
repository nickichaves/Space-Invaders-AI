# Space-Invaders-AI
Space Invaders game played by an AI, using neural networks and genetic algorithm.
